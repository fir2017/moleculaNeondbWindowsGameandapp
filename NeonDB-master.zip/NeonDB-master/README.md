# NeonDB
A python based Database Management System (CLI)
